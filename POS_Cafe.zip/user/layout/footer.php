</div>
    </div>
    <script src="../admin/plugins/common/common.min.js"></script>
    <script src="../admin/js/custom.min.js"></script>
    <script src="../admin/js/settings.js"></script>
    <script src="../admin/js/gleek.js"></script>
    <script src="../admin/js/styleSwitcher.js"></script>
</body>
</html>