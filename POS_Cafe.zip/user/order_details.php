<?php
require_once '../require/db.php';
session_start();

if (!isset($_SESSION['waiter_id'])) {
    header("Location: login.php");
    exit;
}

$order_id = $_GET['order_id'] ?? 0;

if (empty($order_id)) {
    header("Location: index.php");
    exit;
}

// Handle Payment
if (isset($_POST['process_payment'])) {
    $payment_type_id = $_POST['payment_type_id'];
    $payment_date = date('Y-m-d');
    $transaction_code = 'TRN-' . time(); // Example transaction code

    // Insert into payment table
    $stmt = $mysqli->prepare("INSERT INTO payment (order_id, payment_type_id, payment_date, transaction_code) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $order_id, $payment_type_id, $payment_date, $transaction_code);
    $stmt->execute();

    // Update order status
    $stmt = $mysqli->prepare("UPDATE orders SET status = 'completed' WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();

    // Update table status
    $order_result = $mysqli->query("SELECT table_id FROM orders WHERE id = $order_id");
    $order = $order_result->fetch_assoc();
    $table_id = $order['table_id'];
    $stmt = $mysqli->prepare("UPDATE tables SET status = 'available' WHERE id = ?");
    $stmt->bind_param("i", $table_id);
    $stmt->execute();

    header("Location: order_history.php");
    exit;
}


// Fetch order details
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

// Fetch order items
$stmt = $mysqli->prepare("
    SELECT oi.quantity, oi.unit_price, p.name as product_name
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order_items = $result->fetch_all(MYSQLI_ASSOC);

// Fetch payment types
$payment_types_result = $mysqli->query("SELECT * FROM payment_type ORDER BY name ASC");
$payment_types = $payment_types_result->fetch_all(MYSQLI_ASSOC);


include 'layout/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Order #<?= $order_id ?> Details</h4>
                    <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order_items as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td>$<?= number_format($item['unit_price'], 2) ?></td>
                                    <td>$<?= number_format($item['quantity'] * $item['unit_price'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-right">Grand Total:</th>
                                    <th>$<?= number_format($order['total_amount'], 2) ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Payment</h4>
                    <?php if ($order['status'] == 'pending'): ?>
                    <form action="order_details.php?order_id=<?= $order_id ?>" method="post">
                        <div class="form-group">
                            <label for="payment_type_id">Payment Method</label>
                            <select name="payment_type_id" id="payment_type_id" class="form-control" required>
                                <option value="">Select Payment Method</option>
                                <?php foreach ($payment_types as $type): ?>
                                    <option value="<?= $type['id'] ?>"><?= htmlspecialchars($type['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="process_payment" class="btn btn-success btn-block">Process Payment</button>
                    </form>
                    <?php else: ?>
                        <p class="text-success">This order has been paid.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'layout/footer.php'; ?>
