<?php
$admin_base_url = "http://localhost/POS_Cafe/admin/";
$base_url = "http://localhost/POS_Cafe/";
